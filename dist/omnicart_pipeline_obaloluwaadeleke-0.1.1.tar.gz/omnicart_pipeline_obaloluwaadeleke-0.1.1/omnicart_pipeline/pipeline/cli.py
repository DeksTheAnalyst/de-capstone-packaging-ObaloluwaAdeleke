
from omnicart_pipeline.pipeline import Pipeline

def main():
    Pipeline().run()
    print("Pipeline executed successfully!")

if __name__ == "__main__":
    main()
