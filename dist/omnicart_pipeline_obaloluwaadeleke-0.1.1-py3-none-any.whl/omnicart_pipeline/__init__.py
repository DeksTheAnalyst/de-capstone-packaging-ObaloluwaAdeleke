# omnicart_pipeline/__init__.py
from .pipeline.pipeline import Pipeline

__all__ = ["Pipeline"]